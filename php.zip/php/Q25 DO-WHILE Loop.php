<?php

    $i = 1;
    do{
        echo "The number is " . $i . "\n";
    	$i++;
    }while($i <= 3);

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");   
?>