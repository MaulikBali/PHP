<?php
$string = "<b>Hello, world! This is a PHP string.</b>";
echo $string . "<br>";
$string_length = strlen($string);

$word_count = str_word_count($string);

echo "The length of the string is: $string_length<br>";
echo "The number of words in the string is: $word_count<br>";
echo "<br>This program is written by Maulik Bali<br>ERPID-0221BCA026";
?>
