<?php

    $x = 10;
    echo "$x <br>";
    
    $x = 20;
    $x += 30;
    echo "$x <br>";
    
    $x = 50;
    $x -= 20;
    echo "$x <br>";
    
    $x = 5;
    $x *= 25;
    echo "$x <br>";
    
    $x = 50;
    $x /= 10;
    echo "$x <br>";
    
    $x = 100;
    $x %= 15;
    echo "$x <br>";

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>