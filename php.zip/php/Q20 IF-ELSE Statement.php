<?php

    $a = 20;
    $b = 15;
    
    if ($a > $b)
    {
       	echo "$a is bigger than $b";
    }
    else
    {
     	echo "$a is NOT bigger than $b";
    }
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>