<html>
<head>
<title>Writing PHP functions with Parameters</title>
</head>
<body>
<?php
Function addFunction($num1,$num2){
$sum=$num1+$num2;
echo"Sum of the two numbers is: $sum";
}
addFunction(10,20);
echo"<br>";
echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>
</body>
</html>