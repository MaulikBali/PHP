<?php

    $i = 1;
    while ($i <= 10)
    {
        echo $i;  
        echo "\t";
        $i++;
    }
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>