<?php

    $x = 10;
    $y = 4;
    
    echo "$x + $y = ". ($x + $y) . "<br>";
    echo "$x - $y = ". ($x - $y) . "<br>";
    echo "$x * $y = ". ($x * $y) . "<br>";
    echo "$x / $y = ". ($x / $y) . "<br>";
    echo "$x % $y = ". ($x % $y) . "<br>";

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>





