<?php

    $a = 10;
    $b = 20;
    if($a < $b)
    {
    	echo "Out of $a and $b, $a is smaller.." ;
    }
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>