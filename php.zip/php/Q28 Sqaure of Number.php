<?php
// Define the number
$number = 5;

// Calculate the square
$square = $number * $number;

// Output the result
echo "The square of " . $number . " is: " . $square;

echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>
