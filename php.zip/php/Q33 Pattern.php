<?php
  for($i=13; $i>=1;$i--)  {
      for($j=1;$j<=$i;$j++) {
          echo "* ";
      }
    echo "<br>";
}
echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>