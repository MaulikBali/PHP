<?php
$t = time();
$fd = date('Y-m-d H:i:s', $t);

echo "Unix Timestamp: " . $t . "<br>";
echo "Formatted Date: " . $fd . "<br>";
echo "<br>This program is written by Maulik Bali<br>ERPID-0221BCA026";
?>
