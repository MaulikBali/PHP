<?php

    $x = 25;
    $y = 35;
    $z = "25";
    
    var_dump($x == $z); 
    var_dump($x === $z);
    var_dump($x != $y); 
    var_dump($x !== $z);
    var_dump($x < $y);  
    var_dump($x > $y);  
    var_dump($x <= $y); 
    var_dump($x >= $y); 

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>