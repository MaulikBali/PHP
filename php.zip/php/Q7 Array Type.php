<?php

    $colors = array("Red", "Green", "Blue");
    var_dump($colors);
     
    $color_codes = array(
        "Red" => "#ff0000",
        "Green" => "#00ff00",
        "Blue" => "#0000ff");
    var_dump($color_codes);
    
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>