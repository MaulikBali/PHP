<?php

    // Open a file for reading
    $handle = fopen("note.txt", "r");
    var_dump($handle);

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>