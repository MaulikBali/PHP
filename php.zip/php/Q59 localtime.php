<?php
print_r(localtime());
echo "<br><br>";
print_r(localtime(time(),true));
echo "<br>This program is written by Maulik Bali<br>ERPID-0221BCA026";
?>