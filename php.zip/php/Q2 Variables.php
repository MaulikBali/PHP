<?php
    $str="hello string";  
    $x=20;  
    $y=3.16;  
    echo "String is: $str <br>";  
    echo "Integer is: $x <br>";  
    echo "Float is: $y <br>";
    echo("This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>