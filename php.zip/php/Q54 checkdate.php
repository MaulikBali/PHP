<?php
var_dump(checkdate(12,31,-400));
echo "<br>";
var_dump(checkdate(2,29,2003));
echo "<br>";
var_dump(checkdate(2,31,2004));
echo "<br>";
echo "<br>This program is written by Maulik Bali<br>ERPID-0221BCA026";
?>