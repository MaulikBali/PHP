<?php

    $x = "Hello";
    $y = " World!";
    echo $x . $y; // Outputs: Hello World!
    echo "<br>";
    $x .= $y;
    echo $x; // Outputs: Hello World!

    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>