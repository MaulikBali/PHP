<?php

    $a = NULL;
    var_dump($a);
     
    $b = "Hello World!";
    $b = NULL;
    var_dump($b);
    
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>