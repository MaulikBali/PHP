<?php

    function test(){
         $greet="Hello World!";
         echo $greet;
}

test();
echo $greet;
echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>
