<?php
    // Assign the value TRUE to a variable
    $show_error = true;
    var_dump($show_error);
    echo("<br>This program is written by Maulik Bali<br>ERPID-0221BCA026");
?>